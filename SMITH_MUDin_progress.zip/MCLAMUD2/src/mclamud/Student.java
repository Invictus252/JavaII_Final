package mclamud;

public class Student extends Player {
    
      
    public Student(){
        this.name = "Student";
        this.description = "A Student";
        this.hitPoints = 50;
        this.armorClass = 14;
        this.acMOD = this.getACmod();
    }

    
    
   
    
}
